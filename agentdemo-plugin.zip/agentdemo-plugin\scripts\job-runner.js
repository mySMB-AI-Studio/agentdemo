/**
 * AgentDemo Job Runner
 * Standalone script spawned by the MCP server to run demo capture in the background.
 * Usage: node job-runner.js <path-to-opts.json>
 */

import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import fs from 'fs';
import path from 'path';
import os from 'os';

const require = createRequire(import.meta.url);
const dotenv = require('dotenv');

// Load .env from agentdemo root (works for both src/ and plugin scripts/)
const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__dirname, '../.env'), override: true });

import { runCreate } from './create.js';

// ── Read opts ────────────────────────────────────────────────────────────────

const optsFilePath = process.argv[2];
if (!optsFilePath) {
  console.error('job-runner: missing opts file path');
  process.exit(1);
}

let opts;
try {
  opts = JSON.parse(fs.readFileSync(optsFilePath, 'utf8'));
} catch (err) {
  console.error(`job-runner: bad opts file: ${err.message}`);
  process.exit(1);
}

// ── Job status helpers ───────────────────────────────────────────────────────

const jobId = opts._jobId;
if (!jobId) {
  console.error('job-runner: opts missing _jobId');
  process.exit(1);
}

const jobDir = path.join(os.homedir(), '.agentdemo', 'jobs', jobId);
const statusFile = path.join(jobDir, 'status.json');

function writeStatus(patch) {
  try {
    const cur = fs.existsSync(statusFile)
      ? JSON.parse(fs.readFileSync(statusFile, 'utf8'))
      : {};
    fs.writeFileSync(
      statusFile,
      JSON.stringify({ ...cur, ...patch, updated_at: new Date().toISOString() }, null, 2),
    );
  } catch { /* best-effort */ }
}

// ── Run ──────────────────────────────────────────────────────────────────────

writeStatus({ state: 'running', started_at: new Date().toISOString() });

// Pass statusFile path so runCreate can write per-slide progress
opts.statusFile = statusFile;

try {
  await runCreate(opts);
  writeStatus({ state: 'complete', completed_at: new Date().toISOString() });
} catch (err) {
  writeStatus({ state: 'failed', error: err.message, failed_at: new Date().toISOString() });
  process.exit(1);
}
