/**
 * AgentDemo MCP Server
 * Exposes AgentDemo functionality as MCP tools for use in Claude Code.
 */

import { createRequire } from 'module';
import { fileURLToPath as _fileURLToPath } from 'url';
const require = createRequire(import.meta.url);
const dotenv = require('dotenv');
const path = require('path');

// Load .env from agentdemo root folder.
// Use fileURLToPath so that URL-encoded spaces (%20) in the path are decoded
// correctly on Windows — new URL(import.meta.url).pathname leaves them encoded.
const __mcpDir = path.dirname(_fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__mcpDir, '../.env'), override: true });

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import os from 'os';
import crypto from 'crypto';
import { runPlan } from './create.js';
import { runGenerate } from './generate.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DEMOS_DIR = path.join(__dirname, '..', 'demos');

// ── Tool definitions ──────────────────────────────────────────────────────────

const TOOLS = [
  {
    name: 'plan_demo',
    description:
      'Plan a demo without capturing anything. Runs Copilot Studio discovery and AI script generation, ' +
      'then returns the planned slide list, the conversation script, and a list of any missing inputs ' +
      '(platform URLs, auth sessions) needed before create_demo can run. ' +
      'Use this BEFORE queue_demo to validate the approach and identify what to collect from the user.',
    inputSchema: {
      type: 'object',
      properties: {
        studio_url: { type: 'string', description: 'Copilot Studio agent URL' },
        m365_url: { type: 'string', description: 'M365 Copilot chat URL where the agent is published' },
        agent_name: { type: 'string', description: 'Agent name override if Studio discovery is unavailable' },
        instructions: { type: 'string', description: 'Agent instructions override' },
        platforms: { type: 'string', description: 'Comma-separated list of platforms the agent connects to' },
        sharepoint_url: { type: 'string', description: 'SharePoint URL if already known' },
        power_automate_url: { type: 'string', description: 'Power Automate URL if already known' },
        teams_url: { type: 'string', description: 'Teams URL if already known' },
        outlook_url: { type: 'string', description: 'Outlook URL if already known' },
        xero_url: { type: 'string', description: 'Xero URL if already known' },
        outlook_recipient_url: {
          type: 'string',
          description: "Outlook inbox URL for the email recipient (volunteer/approver) — requires a saved session for the recipient account",
        },
        outlook_recipient_profile: {
          type: 'string',
          description: "Name of the saved auth profile for the recipient account (default: 'recipient'). Run: agentdemo auth --profile recipient",
        },
        headless: { type: 'boolean', description: 'Run browser in headless mode (default: true)', default: true },
      },
      required: ['studio_url', 'm365_url'],
    },
  },
  {
    name: 'queue_demo',
    description:
      'Queue a new interactive demo for background capture. Returns immediately with a job_id. ' +
      'The capture runs in a detached background process — use get_demo_status with the job_id to check progress. ' +
      'Provide the Copilot Studio URL and the M365 Copilot URL. ' +
      'Optionally supply a slug (folder name) and whether to run headless.',
    inputSchema: {
      type: 'object',
      properties: {
        studio_url: {
          type: 'string',
          description: 'Copilot Studio agent URL (the "Go to Copilot Studio" link)',
        },
        m365_url: {
          type: 'string',
          description: 'M365 Copilot chat URL where the agent is published',
        },
        agent_name: {
          type: 'string',
          description: 'Agent name to use if Copilot Studio discovery fails',
        },
        instructions: {
          type: 'string',
          description: 'Agent instructions to use if Copilot Studio discovery fails',
        },
        prompts: {
          type: 'string',
          description: 'Pipe-separated (|) list of exact prompts to send in sequence, bypassing AI script generation. Each prompt becomes its own slide.',
        },
        platforms: {
          type: 'string',
          description: 'Comma-separated list of platforms the agent connects to (e.g. "sharepoint,power-automate")',
        },
        sharepoint_url: {
          type: 'string',
          description: 'Comma-separated SharePoint URL(s) to capture (supports multiple)',
        },
        power_automate_url: {
          type: 'string',
          description: 'URL of the Power Automate cloud flows page to capture',
        },
        teams_url: {
          type: 'string',
          description: 'URL of the Teams channel to capture',
        },
        outlook_url: {
          type: 'string',
          description: 'URL of the Outlook email or folder to capture',
        },
        xero_url: {
          type: 'string',
          description: 'URL of the Xero page to capture',
        },
        custom_urls: {
          type: 'string',
          description: 'Comma-separated URLs for custom platform captures',
        },
        outlook_recipient_url: {
          type: 'string',
          description: "Outlook inbox URL for the email recipient (volunteer/approver) — requires a saved session for the recipient account",
        },
        outlook_recipient_profile: {
          type: 'string',
          description: "Name of the saved auth profile for the recipient account (default: 'recipient'). Run: agentdemo auth --profile recipient",
        },
        slug: {
          type: 'string',
          description: 'Optional folder name for the demo (auto-derived from agent name if omitted)',
        },
        headless: {
          type: 'boolean',
          description: 'Run browser in headless mode (default: false)',
          default: false,
        },
      },
      required: ['studio_url', 'm365_url'],
    },
  },
  {
    name: 'get_demo_status',
    description:
      'Get the current status of a demo. Accepts either a slug (demo folder name) or a job_id (from queue_demo). ' +
      'When using job_id, returns background job progress including state, slides_captured, and phase.',
    inputSchema: {
      type: 'object',
      properties: {
        slug: {
          type: 'string',
          description: 'Demo folder name (as shown by list_demos)',
        },
        job_id: {
          type: 'string',
          description: 'Job ID returned by queue_demo — reads progress from the background job status file',
        },
      },
    },
  },
  {
    name: 'resume_demo',
    description:
      'Resume a previously started demo capture session that was interrupted. ' +
      'Picks up from the last captured slide.',
    inputSchema: {
      type: 'object',
      properties: {
        slug: {
          type: 'string',
          description: 'Demo folder name to resume',
        },
        headless: {
          type: 'boolean',
          description: 'Run browser in headless mode (default: false)',
          default: false,
        },
      },
      required: ['slug'],
    },
  },
  {
    name: 'list_demos',
    description: 'List all demos that have been created, with their status and output paths.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'generate_demo_html',
    description:
      'Re-generate the demo HTML output file from existing captured screenshots without re-running the browser. ' +
      'Useful for refreshing the HTML after manual edits to screenshots or config.',
    inputSchema: {
      type: 'object',
      properties: {
        slug: {
          type: 'string',
          description: 'Demo folder name',
        },
      },
      required: ['slug'],
    },
  },
];

// ── Tool handlers ─────────────────────────────────────────────────────────────

async function handlePlanDemo(args) {
  const {
    studio_url, m365_url, agent_name, instructions, platforms,
    sharepoint_url, power_automate_url, teams_url, outlook_url, xero_url,
    outlook_recipient_url, outlook_recipient_profile,
    headless = true,
  } = args;

  if (!studio_url || !m365_url) {
    return { error: 'studio_url and m365_url are required' };
  }

  try {
    return await runPlan({
      studioUrl: studio_url,
      m365Url: m365_url,
      agentName: agent_name || undefined,
      instructions: instructions || undefined,
      platforms: platforms || undefined,
      sharepointUrl: sharepoint_url || undefined,
      powerAutomateUrl: power_automate_url || undefined,
      teamsUrl: teams_url || undefined,
      outlookUrl: outlook_url || undefined,
      xeroUrl: xero_url || undefined,
      outlookRecipientUrl: outlook_recipient_url || undefined,
      outlookRecipientProfile: outlook_recipient_profile || undefined,
      headless,
    });
  } catch (err) {
    return { error: err.message };
  }
}

async function handleQueueDemo(args) {
  const {
    studio_url, m365_url, agent_name, instructions, prompts, platforms,
    sharepoint_url, power_automate_url, teams_url, outlook_url, xero_url, custom_urls,
    outlook_recipient_url, outlook_recipient_profile,
    slug, headless = false,
  } = args;

  if (!studio_url || !m365_url) {
    return { error: 'studio_url and m365_url are required' };
  }

  // Generate unique job ID
  const jobId = crypto.randomBytes(8).toString('hex');
  const jobDir = path.join(os.homedir(), '.agentdemo', 'jobs', jobId);
  fs.mkdirSync(jobDir, { recursive: true });

  // Convert pipe-separated prompts string into array
  const promptsArr = prompts ? prompts.split('|').map(p => p.trim()).filter(Boolean) : undefined;

  // Convert CSV strings into arrays for runCreate
  const customUrlArr = custom_urls ? custom_urls.split(',').map(u => u.trim()).filter(Boolean) : undefined;
  const spUrlArr = sharepoint_url ? sharepoint_url.split(',').map(u => u.trim()).filter(Boolean) : undefined;

  // Build opts for the background runner
  const opts = {
    _jobId: jobId,
    studioUrl: studio_url,
    m365Url: m365_url,
    agentName: agent_name || undefined,
    instructions: instructions || undefined,
    prompts: promptsArr,
    platforms: platforms || undefined,
    sharepointUrl: spUrlArr,
    powerAutomateUrl: power_automate_url || undefined,
    teamsUrl: teams_url || undefined,
    outlookUrl: outlook_url || undefined,
    xeroUrl: xero_url || undefined,
    customUrl: customUrlArr,
    outlookRecipientUrl: outlook_recipient_url || undefined,
    outlookRecipientProfile: outlook_recipient_profile || undefined,
    slug: slug || undefined,
    headless,
    mcpMode: true,
  };

  // Write opts and initial status
  const optsFile = path.join(jobDir, 'opts.json');
  fs.writeFileSync(optsFile, JSON.stringify(opts, null, 2));
  fs.writeFileSync(path.join(jobDir, 'status.json'), JSON.stringify({
    job_id: jobId,
    state: 'queued',
    agent_name: agent_name || null,
    slug: slug || null,
    queued_at: new Date().toISOString(),
    slides_captured: 0,
    phase: null,
    output_path: null,
    error: null,
  }, null, 2));

  // Spawn detached background process
  const child = spawn(process.execPath, [path.join(__dirname, 'job-runner.js'), optsFile], {
    detached: true,
    stdio: 'ignore',
    env: { ...process.env },
  });
  child.unref();

  return {
    success: true,
    job_id: jobId,
    state: 'queued',
    message: `Demo capture started in background. Use get_demo_status with job_id "${jobId}" to check progress.`,
  };
}

async function handleGetDemoStatus(args) {
  const { slug, job_id } = args;

  // Job ID path — read from background job status file
  if (job_id) {
    const statusFile = path.join(os.homedir(), '.agentdemo', 'jobs', job_id, 'status.json');
    if (!fs.existsSync(statusFile)) {
      return { error: `Job "${job_id}" not found.` };
    }
    try {
      const status = JSON.parse(fs.readFileSync(statusFile, 'utf8'));
      // If complete and we have a slug, merge in demo info
      if (status.state === 'complete' && status.slug) {
        const demoDir = path.join(DEMOS_DIR, status.slug);
        if (fs.existsSync(demoDir)) {
          status.demo = getDemoStatus(status.slug, demoDir);
        }
      }
      return status;
    } catch (err) {
      return { error: `Failed to read job status: ${err.message}` };
    }
  }

  // Slug path — existing behavior
  if (!slug) {
    return { error: 'Provide either slug or job_id.' };
  }
  const demoDir = path.join(DEMOS_DIR, slug);
  if (!fs.existsSync(demoDir)) {
    return { error: `Demo "${slug}" not found. Run list_demos to see available demos.` };
  }
  return getDemoStatus(slug, demoDir);
}

async function handleResumeDemo(args) {
  const { slug, headless = false } = args;
  const demoDir = path.join(DEMOS_DIR, slug);

  if (!fs.existsSync(demoDir)) {
    return { error: `Demo "${slug}" not found.` };
  }

  // Find session meta for config path
  const metaPath = path.join(demoDir, '.session-meta.json');
  if (!fs.existsSync(metaPath)) {
    return { error: `No session metadata found for "${slug}". Cannot resume.` };
  }

  try {
    const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
    const configPath = meta.config_path;

    if (!configPath || !fs.existsSync(configPath)) {
      return { error: `Config path not found in session metadata.` };
    }

    const { runResume } = await import('./capture.js');
    await runResume({ config: configPath, headless });

    return {
      success: true,
      message: `Demo "${slug}" resumed successfully.`,
      status: getDemoStatus(slug, demoDir),
    };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

async function handleListDemos() {
  if (!fs.existsSync(DEMOS_DIR)) {
    return { demos: [], message: 'No demos directory found. Run queue_demo to get started.' };
  }

  const demos = getDemoList();
  if (demos.length === 0) {
    return { demos: [], message: 'No demos found. Run queue_demo to get started.' };
  }

  return { demos };
}

async function handleGenerateDemoHtml(args) {
  const { slug } = args;
  const demoDir = path.join(DEMOS_DIR, slug);

  if (!fs.existsSync(demoDir)) {
    return { error: `Demo "${slug}" not found.` };
  }

  // Look for a YAML config in the demo dir
  const configFiles = fs.readdirSync(demoDir).filter(f => f.endsWith('.yml') || f.endsWith('.yaml'));
  if (configFiles.length === 0) {
    // Try generate from session meta
    const metaPath = path.join(demoDir, '.session-meta.json');
    if (!fs.existsSync(metaPath)) {
      return { error: `No config file or session metadata found in "${slug}".` };
    }
    const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
    if (!meta.config_path || !fs.existsSync(meta.config_path)) {
      return { error: `Config path in session metadata does not exist.` };
    }
    try {
      await runGenerate({ config: meta.config_path });
      const outputPath = path.join(demoDir, 'output', 'demo.html');
      return {
        success: true,
        message: `HTML regenerated successfully.`,
        output_path: outputPath,
      };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  const configPath = path.join(demoDir, configFiles[0]);
  try {
    await runGenerate({ config: configPath });
    const outputPath = path.join(demoDir, 'output', 'demo.html');
    return {
      success: true,
      message: `HTML regenerated from ${configFiles[0]}.`,
      output_path: outputPath,
    };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function getDemoStatus(slug, demoDir) {
  const screenshotsDir = path.join(demoDir, 'screenshots');
  const clipsDir = path.join(demoDir, 'clips');
  const outputDir = path.join(demoDir, 'output');
  const outputHtml = path.join(outputDir, 'demo.html');
  const metaPath = path.join(demoDir, '.session-meta.json');

  const screenshots = fs.existsSync(screenshotsDir)
    ? fs.readdirSync(screenshotsDir).filter(f => f.endsWith('.png')).length
    : 0;

  const clips = fs.existsSync(clipsDir)
    ? fs.readdirSync(clipsDir).filter(f => f.endsWith('.mp4') || f.endsWith('.webm')).length
    : 0;

  const hasHtml = fs.existsSync(outputHtml);

  let meta = null;
  if (fs.existsSync(metaPath)) {
    try { meta = JSON.parse(fs.readFileSync(metaPath, 'utf8')); } catch {}
  }

  return {
    slug,
    path: demoDir,
    screenshots,
    clips,
    has_html: hasHtml,
    output_path: hasHtml ? outputHtml : null,
    agent_name: meta?.agent_name || null,
    created_at: meta?.created_at || null,
    last_updated: meta?.last_generated || meta?.created_at || null,
    status: hasHtml ? 'complete' : screenshots > 0 ? 'captured' : 'empty',
  };
}

function getDemoList() {
  if (!fs.existsSync(DEMOS_DIR)) return [];

  return fs.readdirSync(DEMOS_DIR)
    .filter(name => {
      const full = path.join(DEMOS_DIR, name);
      return fs.statSync(full).isDirectory();
    })
    .map(slug => getDemoStatus(slug, path.join(DEMOS_DIR, slug)));
}

// ── Server setup ──────────────────────────────────────────────────────────────

const server = new Server(
  { name: 'agentdemo', version: '1.0.0' },
  { capabilities: { tools: {} } }
);

server.setRequestHandler(ListToolsRequestSchema, async () => ({ tools: TOOLS }));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  let result;
  switch (name) {
    case 'plan_demo':         result = await handlePlanDemo(args); break;
    case 'queue_demo':        result = await handleQueueDemo(args); break;
    case 'get_demo_status':   result = await handleGetDemoStatus(args); break;
    case 'resume_demo':       result = await handleResumeDemo(args); break;
    case 'list_demos':        result = await handleListDemos(); break;
    case 'generate_demo_html': result = await handleGenerateDemoHtml(args); break;
    default:
      result = { error: `Unknown tool: ${name}` };
  }

  return {
    content: [
      {
        type: 'text',
        text: JSON.stringify(result, null, 2),
      },
    ],
    isError: !!(result.error),
  };
});

// ── Start ─────────────────────────────────────────────────────────────────────

const transport = new StdioServerTransport();
await server.connect(transport);
console.error('AgentDemo MCP server running on stdio');
